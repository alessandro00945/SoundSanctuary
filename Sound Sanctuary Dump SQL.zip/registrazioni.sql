-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 21, 2025 alle 10:40
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio_di_registrazione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `registrazioni`
--

CREATE TABLE `registrazioni` (
  `id` int(11) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `musicista_id` int(10) UNSIGNED NOT NULL,
  `sala` varchar(100) NOT NULL,
  `data_registrazione` timestamp NOT NULL DEFAULT current_timestamp(),
  `file_path` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `inserito_da` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `registrazioni`
--

INSERT INTO `registrazioni` (`id`, `titolo`, `musicista_id`, `sala`, `data_registrazione`, `file_path`, `note`, `inserito_da`) VALUES
(1, 'cccc', 1, 'Sala Rock', '2025-06-20 22:00:00', '../uploads/registrazioni/1750494521_MinaCelentano_-_A_Un_Passo_Da_Te__Mina___Celentano_.mp3', 'ccccc', 6);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `registrazioni`
--
ALTER TABLE `registrazioni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `musicista_id` (`musicista_id`),
  ADD KEY `inserito_da` (`inserito_da`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `registrazioni`
--
ALTER TABLE `registrazioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `registrazioni`
--
ALTER TABLE `registrazioni`
  ADD CONSTRAINT `registrazioni_ibfk_1` FOREIGN KEY (`musicista_id`) REFERENCES `utenti` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrazioni_ibfk_2` FOREIGN KEY (`inserito_da`) REFERENCES `utenti` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
