-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 21, 2025 alle 10:40
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio_di_registrazione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `prenotazioni`
--

CREATE TABLE `prenotazioni` (
  `id` int(11) NOT NULL,
  `utente_id` int(11) NOT NULL,
  `sala` varchar(100) DEFAULT NULL,
  `produttore` varchar(100) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `orario` varchar(20) DEFAULT NULL,
  `strumenti` text DEFAULT NULL,
  `stato` enum('in_attesa','approvata','rifiutata') DEFAULT 'in_attesa',
  `data_richiesta` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_ora_inizio` datetime DEFAULT NULL,
  `data_ora_fine` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `prenotazioni`
--

INSERT INTO `prenotazioni` (`id`, `utente_id`, `sala`, `produttore`, `data`, `orario`, `strumenti`, `stato`, `data_richiesta`, `data_ora_inizio`, `data_ora_fine`) VALUES
(18, 1, 'Sala Rock', 'Butch.Vig', '2025-06-28', '14:00-16:00', 'Microfono, Tastiere, Sassofono, Gibson Limited Edition Vampire Blood Moon Explorer 2011 Ebony/Red', 'rifiutata', '2025-06-16 08:51:11', NULL, NULL),
(34, 1, 'Sala Rock', 'Butch.Vig', '2025-06-19', '08:00-11:00', 'Microfono, Tastiere, Neve 1073', 'approvata', '2025-06-16 14:21:28', NULL, NULL),
(35, 1, 'Sala Rock', 'Butch.Vig', '2025-06-19', '08:00-11:00', 'Microfono, Tastiere, Neve 1073', 'rifiutata', '2025-06-16 14:21:44', NULL, NULL),
(36, 1, 'Sala Rock', 'Butch.Vig', '2025-06-25', '14:00-16:00', NULL, 'rifiutata', '2025-06-16 15:20:03', NULL, NULL),
(37, 1, 'Sala Rock', 'Butch.Vig', '2025-06-25', '14:00-16:00', 'Microfono, Tastiere, Pianoforte, Neve 1073', 'rifiutata', '2025-06-16 15:20:17', NULL, NULL),
(38, 1, 'Sala Rock', 'Butch.Vig', '2025-07-05', '14:00-16:00', NULL, 'rifiutata', '2025-06-16 15:23:51', NULL, NULL),
(39, 1, 'Sala Rock', 'Butch.Vig', '2025-07-05', '14:00-16:00', NULL, 'rifiutata', '2025-06-16 15:33:16', NULL, NULL),
(40, 1, 'Sala Rock', 'Butch.Vig', '2025-06-05', '08:00-11:00', NULL, 'approvata', '2025-06-16 16:16:44', NULL, NULL),
(41, 1, 'Sala Rock', 'Butch.Vig', NULL, NULL, NULL, 'approvata', '2025-06-16 16:25:31', '2025-06-05 14:00:00', '2025-06-05 16:00:00'),
(42, 1, 'Sala Rock', 'Butch.Vig', NULL, NULL, NULL, 'rifiutata', '2025-06-16 16:49:18', '2025-06-13 08:00:00', '2025-06-13 11:00:00'),
(43, 1, 'Sala Rock', 'Butch.Vig', NULL, NULL, NULL, 'rifiutata', '2025-06-16 19:43:57', '2025-06-20 11:00:00', '2025-06-20 13:00:00'),
(44, 1, 'Sala Rock', 'Butch.Vig', NULL, NULL, NULL, 'rifiutata', '2025-06-21 08:30:48', '2025-06-20 11:00:00', '2025-06-20 13:00:00'),
(45, 1, 'Sala Rock', 'Butch.Vig', NULL, NULL, NULL, 'approvata', '2025-06-21 08:37:36', '2025-07-06 11:00:00', '2025-07-06 13:00:00');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `prenotazioni`
--
ALTER TABLE `prenotazioni`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `prenotazioni`
--
ALTER TABLE `prenotazioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
