-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 21, 2025 alle 10:40
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio_di_registrazione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `prenotazione_strumenti`
--

CREATE TABLE `prenotazione_strumenti` (
  `prenotazione_id` int(11) NOT NULL,
  `strumento_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `prenotazione_strumenti`
--

INSERT INTO `prenotazione_strumenti` (`prenotazione_id`, `strumento_id`) VALUES
(39, 13),
(39, 17),
(39, 18),
(39, 21),
(40, 13),
(40, 14),
(40, 15),
(40, 16),
(40, 17),
(40, 18),
(40, 19),
(40, 21),
(41, 13),
(41, 17),
(41, 20),
(42, 13),
(42, 18),
(42, 20),
(43, 13),
(43, 15),
(43, 16),
(43, 17),
(43, 18),
(43, 19),
(43, 20),
(44, 13),
(44, 17),
(44, 18),
(44, 21),
(45, 13),
(45, 14),
(45, 15),
(45, 16),
(45, 17),
(45, 18),
(45, 19),
(45, 20),
(45, 21),
(45, 22);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `prenotazione_strumenti`
--
ALTER TABLE `prenotazione_strumenti`
  ADD PRIMARY KEY (`prenotazione_id`,`strumento_id`),
  ADD KEY `strumento_id` (`strumento_id`);

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `prenotazione_strumenti`
--
ALTER TABLE `prenotazione_strumenti`
  ADD CONSTRAINT `prenotazione_strumenti_ibfk_1` FOREIGN KEY (`prenotazione_id`) REFERENCES `prenotazioni` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `prenotazione_strumenti_ibfk_2` FOREIGN KEY (`strumento_id`) REFERENCES `strumenti` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
