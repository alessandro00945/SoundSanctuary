-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 21, 2025 alle 10:41
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio_di_registrazione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `data_nascita` date NOT NULL,
  `luogo_nascita` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `genere_musicale` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ruolo` enum('musicista','produttore') NOT NULL,
  `data_registrazione` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `username`, `data_nascita`, `luogo_nascita`, `email`, `genere_musicale`, `password`, `ruolo`, `data_registrazione`) VALUES
(1, 'j', 'j', 'j', '2025-05-14', 'caserta', 'j@g.com', 'Rock', '$2y$10$v4zKl7SQGO9H1W8AnwHkzO/LzSYP8vOJSf36V9iOQ/vt/ToiuSir6', 'musicista', '2025-06-14 06:55:54'),
(6, 'Bryan', 'Vigorson', 'Butch.Vig', '1955-08-02', 'Viroqua', 'butch.vig@gmail.com', 'Rock', '$2y$10$vp4DEqf4CDfxrJ19Rm7lKeY34h93XQqf5hARVxOOPjZKyeqWXmDmq', 'produttore', '2025-06-16 08:32:44'),
(7, 'Andre', 'Young', 'Dr.Dre', '1965-02-18', 'Compton', 'dr.dre@gmail.com', 'Rap/Hip-Hop', '$2y$10$n0M42enQzGvxnLeKPYL5xux6Lk1O5E8zbEeEZmlAoLTELPq3yeJzK', 'produttore', '2025-06-16 08:32:44'),
(8, 'Hans', 'Zimmer', 'Hans.Zimmer', '1957-09-12', 'Francoforte sul Meno', 'hans.zimmer@gmail.com', 'Classica', '$2y$10$rYaLVnLrDWvH2fDNvFC.9.hlPcB12ElT1AR9qKKo7NDwKEoUdaFKu', 'produttore', '2025-06-16 08:32:44'),
(9, 'Paolo', 'Fresu', 'Paolo.Fresu', '1961-02-10', 'Berchidda', 'paolo.fresu@gmail.com', 'Jazz', '$2y$10$kOJ2TmPHiCQhxWiVjlVNy.umbfkAmR1m3EW/.M3rZnPw2/V1suP.6', 'produttore', '2025-06-16 08:32:44');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
