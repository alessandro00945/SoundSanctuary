-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 21, 2025 alle 10:41
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio_di_registrazione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `strumenti`
--

CREATE TABLE `strumenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `sala_id` int(11) NOT NULL,
  `sala` varchar(50) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `immagine` varchar(255) DEFAULT NULL,
  `revisione_richiesta` tinyint(1) DEFAULT 0,
  `ore_ultima_revisione` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `strumenti`
--

INSERT INTO `strumenti` (`id`, `nome`, `sala_id`, `sala`, `descrizione`, `immagine`, `revisione_richiesta`, `ore_ultima_revisione`) VALUES
(13, 'Microfono Sala Rock', 1, NULL, '', '', 0, 0),
(14, 'Chitarra elettrica Sala Rock', 1, NULL, '', '', 0, 0),
(15, 'Basso elettrico Sala Rock', 1, NULL, '', '', 0, 0),
(16, 'Batteria Sala Rock', 1, NULL, '', '', 0, 0),
(17, 'Tastiere Sala Rock', 1, NULL, '', '', 0, 0),
(18, 'Pianoforte Sala Rock', 1, NULL, '', '', 0, 0),
(19, 'Sassofono Sala Rock', 1, NULL, '', '', 0, 0),
(20, 'Gibson Limited Edition Vampire Blood Moon Explorer 2011 Ebony/Red Sala Rock', 1, NULL, 'Chitarra elettrica vintage con suono caldo e classico.', '../images/gibson.jpeg', 0, 0),
(21, 'Neve 1073 Sala Rock', 1, NULL, 'Preamp microfonico vintage leggendario.', '../images/preamp.jpg', 0, 0),
(22, 'Ludwig Classic Maple Sala Rock', 1, NULL, 'Batteria vintage con suono potente.', '../images/ludwig.jpg', 0, 0),
(23, 'Microfono Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(24, 'Chitarra elettrica Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(25, 'Basso Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(26, 'Batteria Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(27, 'Tastiere Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(28, 'Sintetizzatori Sala Rap/Hip-Hop', 2, NULL, '', '', 0, 0),
(29, 'Akai Sala Rap/Hip-Hop', 2, NULL, 'Campionatore e drum machine iconico degli anni \'80, fondamentale per il suono Hip-Hop old school.', '../images/akai.jpg', 0, 0),
(30, 'Sonor - Vintage Set 3 Pezzi BD 22 Sala Rap/Hip-Hop', 2, NULL, 'Batteria suonata dal leggendario Dave Grohl.', '../images/sonor.jpg', 0, 0),
(31, 'Microfono Sala Classica', 3, NULL, '', '', 0, 0),
(32, 'Chitarra Classica Sala Classica', 3, NULL, '', '', 0, 0),
(33, 'Pianoforte Sala Classica', 3, NULL, '', '', 0, 0),
(34, 'Violino Sala Classica', 3, NULL, '', '', 0, 0),
(35, 'Flauto Traverso Sala Classica', 3, NULL, '', '', 0, 0),
(36, 'Trombe Sala Classica', 3, NULL, '', '', 0, 0),
(37, 'Eko Fiesta Special chitarra classica vintage anni 60 Sala Classica', 3, NULL, 'Chitarra classica nel ricordo Hippie.', '../images/eko.jpg', 0, 0),
(38, 'FoxGear V-100 British Classic Vintage Amp 100W Amplificatore a pedale Sala Classica', 3, NULL, 'Amplificatore anni 80', '../images/amp.jpg', 0, 0),
(39, 'Microfono Sala Jazz', 4, NULL, '', '', 0, 0),
(40, 'Tromba Sala Jazz', 4, NULL, '', '', 0, 0),
(41, 'Trombone Sala Jazz', 4, NULL, '', '', 0, 0),
(42, 'Clarinetto Sala Jazz', 4, NULL, '', '', 0, 0),
(43, 'Sassofono Sala Jazz', 4, NULL, '', '', 0, 0),
(44, 'Pianoforte Sala Jazz', 4, NULL, '', '', 0, 0),
(45, 'Sassofono Eastar AS-II E-Flat Sala Jazz', 4, NULL, 'Sassofono anni 70.', '../images/sa.webp', 0, 0),
(46, 'Fender American Vintage Ii 1966 Jazz Bass Ss Rw Olympic White Sala Jazz', 4, NULL, 'Chitarra 1966 white', '../images/fe.jpg', 0, 0);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `strumenti`
--
ALTER TABLE `strumenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`),
  ADD KEY `sala_id` (`sala_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `strumenti`
--
ALTER TABLE `strumenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
